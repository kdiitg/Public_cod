simply put this folder any where
now go to enviroment variable and in path set path
....finished !!